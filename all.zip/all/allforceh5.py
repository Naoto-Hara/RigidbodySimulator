import h5py
import numpy as np
from forceh5 import *

class AllForceData:
    def __init__(self):
        self.all_step_ForceData = []

    def __load_forces(self, fileName):
        self.all_step_ForceData.clear()
        
        
        if fileName != "" and fileName[len(fileName)-3:] == ".h5":
            
            with h5py.File(fileName, 'r') as h5_forces:
                #REVIEW:ファイルは1から始まることを前提とした長さ
                dt_group_num = len(h5_forces)-1
                for i in range(dt_group_num):
                    data_group = h5_forces[str(i+1)]
                    f_group = data_group['forces_2d']
                    position_array = np.array(f_group['position'], dtype=np.float64)
                    arm_array = np.array(f_group['arm'], dtype=np.float64)
                    force_array = np.array(f_group['force'], dtype=np.float64)

                    num_forces = position_array.shape[1]

                    force = ForceData()
                    for i in range(num_forces):
                        f = Force()
                        f.position = position_array[:,i]
                        f.arm = arm_array[:,i]
                        f.force = force_array[:,i]
                        force.forces.append(f)
                    self.all_step_ForceData.append(force)
                

    def load(self, fn_element):
        self.__load_forces(fn_element)
