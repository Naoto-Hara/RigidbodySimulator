from homogenizer import *
from allforceh5 import *
from progressh5 import *
from allhomogenizationh5 import *

#全ステップの力をロードする。allforce[step]=forceData()
template_fn="/Users/naoto/Downloads/flow_stress/square_merge_template.h5"
element_fn="/Users/naoto/Downloads/flow_stress/serialized_forces.h5"
allforce_data = AllForceData()
allforce_data.load(element_fn)
progress_data = ProgressData()
progress_data.load(element_fn)

#gridのパラメータ
#REVIEW:xmlからグリッドのパラメータを読み込む
grid_start_offset_ratio = np.array([0.0, 0.0])
h = 0.04

allhomogenization_data = AllHomogenizeData()
#全ステップの力を均質化する
for i, data in enumerate(allforce_data.all_step_ForceData):
    force_data = data
    homogenization_data = HomogenizeData()
    homogenization_grid = HomogenizationGrid()
    homogenization_grid.setData(grid_start_offset_ratio, h, force_data, homogenization_data)
    allhomogenization_data.all_step_homogenization.append(homogenization_data)

    
time = str(progress_data.progress[0].time)
filename = "/Users/naoto/Downloads/flow_stress/DEMtest_save/time"+time+".h5"
allhomogenization_data.save(filename)
    