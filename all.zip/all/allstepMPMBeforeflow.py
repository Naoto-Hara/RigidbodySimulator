from MPMBeforeflow import *
from allgrainh5 import*
from progressh5 import *
from allhomogenizationh5 import *

#全ステップの力をロード
# elements afterflow step
template_fn="/Users/naoto/Downloads/flow_stress/square_merge_template.h5"
element_fn="/Users/naoto/Downloads/flow_stress/serialized_forces.h5"
allelements = AllSceneData()
allelements.load(template_fn, element_fn)
progress_data = ProgressData()
progress_data.load(element_fn)

#gridのパラメータ
#REVIEW:xmlからグリッド,MPMのパラメータを読み込む
grid_start_offset_ratio = np.array([0.0, 0.0])
h = 0.04

#全ステップの力をMPM半ステップ進める
allhomogenization_data = AllHomogenizeData()
for i, data in enumerate(allelements.all_step_elements):
    MPM_grid = MPMGrains()

    #TODO:dtは2ステップ以上の比較をするときは動的にする必要がある
    dt = progress_data.progress[i].dt
    homogenization_data = HomogenizeData()
    MPM_grid.setData(grid_start_offset_ratio, h, data, homogenization_data, dt)
    allhomogenization_data.all_step_homogenization.append(homogenization_data)

#TODO:フォルダーをprogressの値で分ける
time = str(progress_data.progress[0].time)
filename = "/Users/naoto/Downloads/flow_stress/MPMtest_save/time"+time+".h5"
allhomogenization_data.save(filename)

    