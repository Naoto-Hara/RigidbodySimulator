import xml.etree.ElementTree as ET 
import sys

#TODO:Resumeファイル名取得方法を考える
args = sys.argv
if len(args) < 3:
    print('rewriteResumefn.py template_fn template_fn')
template_fn = args[1]
object_fn = args[2]

resume_xml_fn = '/Users/naoto/Downloads/git-sample/git-sample/code/test.xml'

# XMLファイルを解析
tree = ET.parse(resume_xml_fn)
# XMLを取得
root = tree.getroot()

#resumeファイル名を変更
if root[3].tag !="resume":
    print("not resume line")
resume_template_filepath = root[3].attrib["templates"] 
resume_object_filepath = root[3].attrib["objects"]

resume_template_filepath = resume_template_filepath.split('/')[:-1]
resume_template_filepath.append(template_fn)
resume_template_filepath = "/".join(resume_template_filepath)

resume_object_filepath = resume_object_filepath.split('/')[:-1]
resume_object_filepath.append(object_fn)
resume_object_filepath = "/".join(resume_object_filepath)

# resumeファイルの内容を変更,書き換え
root[3].attrib["templates"] = resume_template_filepath
root[3].attrib["objects"] = resume_object_filepath
tree.write(resume_xml_fn)