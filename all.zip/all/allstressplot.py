from sysconfig import parse_config_h
from stressviewer import *
from allhomogenizationh5 import *

#REVIEW:応力ファイル名の決め方
pre_fn = "/Users/naoto/Downloads/flow_stress/MPMtest_save/time1e-06.h5"
post_fn = "/Users/naoto/Downloads/flow_stress/DEMtest_save/time1e-06.h5"
stress_plot = StressPlot()
fig = go.Figure()
allpre_homogenization_data = AllHomogenizeData()
allpost_homogenization_data = AllHomogenizeData()
allpre_homogenization_data.load(pre_fn)
allpost_homogenization_data.load(post_fn)

#TODO:比較するタイミングを検討
for i in range(len(allpre_homogenization_data.all_step_homogenization)-1):
    pre_homogenization_data = allpre_homogenization_data.all_step_homogenization[i]
    post_homogenization_data = allpost_homogenization_data.all_step_homogenization[i+1]
    stress_plot.setData(pre_homogenization_data, post_homogenization_data, fig)

fig.show()

