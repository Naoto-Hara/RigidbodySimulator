import h5py
import numpy as np
from homogenizationh5 import *

class AllHomogenizeData:
    def __init__(self):
        self.all_step_homogenization = []     

    def _load_homogenization(self, fileName):
        self.all_step_homogenization.clear()
        if fileName != "" and fileName[len(fileName)-3:] == ".h5":
            with h5py.File(fileName, 'r') as h5_homogenization:
                dt_group_num = len(h5_homogenization) - 1
                for i in range(dt_group_num):
                    data_group = h5_homogenization[str(i+1)]
                    h_group = data_group['homogenization']
                    sigma_array = np.array(h_group['sigma'], dtype=np.float64)
                    grid_p_array = np.array(h_group['grid_p'], dtype=np.float64)
                    resolution = np.array(h_group['resolution'], dtype = np.int32)
                    h = np.array(h_group['h'], dtype = np.float64)
                  
                    homogenize_num = len(h)
                    homogenization_data = HomogenizeData()
                    for i in range(homogenize_num):
                        j = Homogenization()
                        j.sigma = sigma_array[:,:,i]
                        j.grid_p = grid_p_array[:,i]
                        j.resolution = resolution[:,i]
                        j.h = h[i]
                        homogenization_data.homogenization.append(j)
                    self.all_step_homogenization.append(homogenization_data)  
                

    def load(self, fn):
        self._load_homogenization(fn)
                      
    def save(self, fileName):
        with h5py.File(fileName ,'w') as h5_homogenization:
            dt_group_num = len(self.all_step_homogenization) - 1
            for i in range(dt_group_num):
                data_group = h5_homogenization.create_group(str(i+1))
                h_group = data_group.create_group('homogenization')
                homogenization = self.all_step_homogenization[i].homogenization
                sigma_array = np.zeros((2,2,len(homogenization)), dtype=np.float64)
                grid_p_array = np.zeros((2,len(homogenization)), dtype=np.float64)
                resolution = np.zeros((2,len(homogenization)), dtype=np.int32)
                h = np.zeros(len(homogenization), dtype=np.float64)
                
                for i in range(len(homogenization)):
                    sigma_array[:,:,i] = homogenization[i].sigma
                    grid_p_array[:,i] = homogenization[i].grid_p
                    resolution[:,i] = homogenization[i].resolution
                    h[i] = homogenization[i].h   
                
                h_group.create_dataset('sigma', data = sigma_array)
                h_group.create_dataset('grid_p', data = grid_p_array)
                h_group.create_dataset('resolution', data = resolution)
                h_group.create_dataset('h', data = h)
            
